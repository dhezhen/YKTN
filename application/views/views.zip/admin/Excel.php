<?php

	if (!defined('BASEPATH'))exit ('No direct Accces Allowed');

	require_once('PHPExcel');

	class Excel extends PHPExcel{

			public function __contruct(){
				parent::__contruct();
			}

	}
	


?>