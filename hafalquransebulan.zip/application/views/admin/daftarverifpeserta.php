<div class="container">
								<h3 class="header smaller lighter blue">Tampilkan Peserta Berdasarkan : </h3>
	<a href="<?php echo site_url('admin/belumdiverifikasi');?>"><button class="btn btn-large btn-danger">Daftar Peserta yang <strong>BELUM</strong> diVerifikasi</button></a>
						<br/><br/><br/>
						<a href="<?php echo site_url('admin/telahverifikasi');?>"><button class="btn btn-large btn-primary">Daftar Peserta yang <strong>SUDAH</strong> diVerifikasi</button></a>
	</div>