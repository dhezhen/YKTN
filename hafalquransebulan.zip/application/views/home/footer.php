<footer class="container-fluid bg-4 text-center">
  <p><marquee>Copyright @2019 Karantina Tahfizh Al-Quran Nasional </p> 
</footer>