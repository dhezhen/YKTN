<h3><p><div class="alert alert-success" role="alert">

	Akun anda <?php echo $peserta->status;
			if ($peserta->status=='belum diverifikasi'){

				echo " <br>silahkan melakukan konfirmasi pembayaran uang registrasi";
			}


	?></div> 


</p></h3>

