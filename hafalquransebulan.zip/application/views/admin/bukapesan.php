<div class="container">
								<h3 class="header smaller lighter blue"><?php echo $pesan->judul;?></h3>
								<div class="well well-lg"><?php echo $pesan->isi;?></div>
	</div>