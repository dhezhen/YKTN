
<div class="jumbotron">
  <marquee>
  Selamat Datang di Halaman Pendaftaran Peserta Karantina Tahfizh Al-Quran Nasional.
  </marquee>
  <h1></h1>
  <p>Selamat Datang di <b>Aplikasi Pendaftaran Online Karantina Tahfizh Al-Quran Nasional .</b> Sebelum melakukan pendaftaran,
  sebaiknya anda memahami prosedur pendaftaran terlebih dahulu. 
  
  <h3 style='text-align: center; '>Prosedur Pendaftaran</h3>
<hr>
	<ol>
	<h4>
        <li>
            <strong>Pendaftaran.</strong> 
            <br>Calon peserta melakukan pendaftaran pada Website registrasi.karantiatahfizh.id (klik tombol <?php echo anchor('ppdb/daftar', 'Daftar'); ?> di bawah) dan silahkan isi Nama lengkap, email dan Password untuk membuat akun.
          
        </li><br/>

		
        <li>
            <strong>Data Yang Harus Disiapkan.</strong> <br>
		        Untuk mengisi formulir siapkan file identitas Diri baik itu KTP/SIM/PASSPORT/Kartu Pelajar/KK maksimal 1Mb, Foto Surat Keterangan Sehat, Foto Diri Background Bebas (file jpg/jpeg/png), .
          </li><br/>

          <li>
            <strong>Mengisi Formulir.</strong> <br>
            Mengisi Formulir Pendafaran dengan teliti dan  benar sebelum disimpan dan dicetak
          </li><br/>

		  <li>
            <strong>Mencetak Formulir yang sudah diisi </strong>. <br>Formulir yang sudah dilengkapi kemudian dicetak di kertas A4. Untuk mencetak, masuk ke menu cetak. Menu ini akan tampil jika Anda sudah login.
            Formulir yang sudah dicetak tersebut selajutnya <strong>dibawa saat registrasi ulang </strong> dan diserahkan kepanitia
      </li><br/>
      
        <li><strong>Pengumuman.</strong> 
		<br>  Setelah melakukan registrasi Staff kami akan menghubungi no yang telah terdaftar untuk melakukan verifikasi dan memberikan arahan ataupun pengumuman lainya
		</li><br/>
        
    </h4></ol>
 
  <p><a class="btn btn-primary btn-lg" href="<?php echo site_url('ppdb/daftar');?>" role="button">Daftar</a></p>
</div>