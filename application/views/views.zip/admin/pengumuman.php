<div class="container">
								<h3 class="header smaller lighter blue">Status pengumuman saat ini : <b><?php echo $pengumuman->status;;?><b/></h3>
								<a href="<?php echo site_url('admin/hidupkanpengumuman');?>"><button class="btn btn-large btn-primary"><strong>HIDUPKAN</strong></button></a>
								<br/><br/><br/>
								<a href="<?php echo site_url('admin/matikanpengumuman');?>"><button class="btn btn-large btn-danger"><strong>MATIKAN</strong></button></a>
	</div>