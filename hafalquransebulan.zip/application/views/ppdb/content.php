
<div class="jumbotron">
  <marquee>
  Selamat Datang di Halaman Pendaftaran Peserta Karantina Tahfizh Al-Quran Nasional Angkatan ke 43
  </marquee>
  <h1></h1>
  <p>Selamat Datang di <b>Aplikasi Pendaftaran Online Karantina Tahfizh Al-Quran Nasional .</b> Sebelum melakukan pendaftaran,
  sebaiknya anda memahami prosedur pendaftaran terlebih dahulu. 
  
  <h3>Prosedur Pendaftaran</h3>
<hr>
	<ol>
	<h4>
        <li>
            <strong>Pendaftaran.</strong> <br>Calon peserta melakukan pendaftaran pada Website 
            <!--< ?php echo anchor('ppdb_controller/pendaftaran', 'Pendaftaran'); ?>.-->
            Kemudian calon peserta akan diarahkan untuk Login menggunakan username dan password yang telah didaftarkan untuk melengkapi Biodata.
        </li><br/>
		
        <li><strong>Data Yang Harus Disiapkan.</strong> <br>
		Untuk mengisi formulir siapkan file identitas Diri(file foto Jpg/Png) baik itu KTP/SIM/PASSPORT/Kartu Pelajar/KK maksimal 1Mb, Foto Surat Keterangan Sehat, Foto Diri Background Bebas, .</li><br/>
		<li>
            <strong>Mencetak Formulir yang sudah diisi </strong>. <br>Formulir yang sudah dilengkapi kemudian dicetak di kertas A4. Untuk mencetak, masuk ke menu cetak. Menu ini akan tampil jika Anda sudah login.
            Formulir yang sudah dicetak tersebut selajutnya <strong>dibawa saat registrasi ulang </strong> dan diserahkan kepanitia
        </li><br/>
      
        <li><strong>Pengumuman.</strong> 
		<br>  Setelah melakukan registrasi Staff kami akan menghubungi no yang telah terdaftar untuk melakukan verifikasi dan memberikan arahan ataupun pengumuman lainya
		</li><br/>
        
    </h4></ol>
 
  <p><a class="btn btn-primary btn-lg" href="<?php echo site_url('ppdb/daftar');?>" role="button">Daftar</a></p>
</div>