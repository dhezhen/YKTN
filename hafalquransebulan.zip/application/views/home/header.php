<div class="container-fluid bg-1 text-center">
  <h1>Karantina Tahfizh Al-Quran Nasional </h1>
  <img src="<?php echo base_url('assets/images/slogan.png');?>" class="img-circle" alt="logo">
  <h3>Jl. Objek Wisata Cibulan RT. 17 Rw 04 Ds.Maniskidul Jalaksana - Kuningan 45554</h3>
</div>

