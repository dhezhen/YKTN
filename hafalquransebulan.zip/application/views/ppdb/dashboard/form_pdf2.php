<table border=5 width="100%">
	<tr>
	<td width="50%">Test</td>
	<td width="50%">Test</td>
	</tr>
</table>